package com.revature.prf.dao;

import com.revature.prf.model.Employee;
import com.revature.prf.model.User;

public interface UserDAO {
	
	public boolean addUser(User user);
	public boolean validateUser(User user);
	public boolean isUserExists(int userId);
	public User getUserById(int userId); 
}
