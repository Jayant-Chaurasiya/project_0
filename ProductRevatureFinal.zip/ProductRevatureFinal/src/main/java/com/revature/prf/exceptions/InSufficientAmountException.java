package com.revature.prf.exceptions;

public class InSufficientAmountException extends RuntimeException {
	public InSufficientAmountException() {
		// TODO Auto-generated constructor stub
	}
	
	public InSufficientAmountException(String msg) {
		super(msg);
		}
}
