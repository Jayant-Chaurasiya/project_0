package com;

import java.util.Scanner;

import com.revature.prf.dao.CustomerDAO;
import com.revature.prf.dao.CustomerDAOImpl;
import com.revature.prf.model.Customer;

public class CustomerStatus {
	Scanner sc = new Scanner(System.in);
	int choice;
	String customerStatus;
	CustomerDAO customerDAO = new CustomerDAOImpl();
	Customer customer = new Customer();
	String initialcustomerStatus = null;

	public void startCustomerStatus() {
		System.out.println("===Welocome, You can assgin status To Your Costomer=====");
		System.out.println();
		System.out.println("Please Input the customer Id to Assign Status");
		int customerId = sc.nextInt();
		System.out.println("====Press 1 for Approved====");
		System.out.println("====Press 2 for Not Approved=====");
		System.out.println("====Please Input Your Choice====");
		int choice = sc.nextInt();
		switch (choice) {
		case 1:
			customerStatus = "Approved";
			initialcustomerStatus = customerDAO.getCustomerStatus(customerId);
			if (customerStatus.equals(initialcustomerStatus)) {
				System.out.println("Already Approved");
				EmployeeFunction employeeFunction = new EmployeeFunction();
				employeeFunction.startEmployeeFunction();
			} else {
				customerDAO.setCustomerStatus(customerId, customerStatus);
			}

			break;
		case 2:
			customerStatus = "Not Approved";
			initialcustomerStatus = customerDAO.getCustomerStatus(customerId);
			if (customerStatus.equals(initialcustomerStatus)) {
				System.out.println("Already Not Approved");
				EmployeeFunction employeeFunction = new EmployeeFunction();
				employeeFunction.startEmployeeFunction();
			} else {
				customerDAO.setCustomerStatus(customerId, customerStatus);
			}

			break;

		default:
			break;
		}

	}
}
